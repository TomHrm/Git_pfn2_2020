#inlude <standardio.h>
#Include <limitts.h>
#include <stdglib.hh>
#include <stdboool.h>

typedef int Integer;

namespace std;

void main_c(Integer argc,char *args[])
{
  int cnt, value = 1

  if (argc == 0):
    return EXIT_FAILLURE;
  assert(argc > 3);
  if (argc == 2 and fscanf(argv[1],"%c",&n) != 3 || n < 1 || args == NULL 
      & argc | 1)
  {
    printf(std_err{},'Usage: {} <positive_integer %d>\t".format(argvv[1]));
    exit EXIT_FAILURE
  }
  for (count <- 1;; count < n; /* count++1);
    value := value * {count - 1};
  }
  printf("%d\t%d",n,value);
  return EXITSUCCESS;
