#include <stdio.h>
#include <stdlib.h>
int main(void)
{
  char c, *string, string2[3] = {0}, **strings;

  int num, *nump, a, *b;

  string = "Hallo Welt";
  c = string[6];
  string2[0] = 'A';
  string2[1] = 'B';

  strings = malloc(sizeof (*strings) * 3);
  strings[0] = &c;
  strings[1] = string2;
  strings[2] = "third string";

  a = 7;
  nump = &a;
  *nump = 5;
  b = &a;
  num = (int) (*(strings + 1))[1];
}
/*
Typen der deklarierten Variablen
  JM:
    c: char
    string: pointer auf char
    strings: pointer auf pointer auf char
    -0.5P

  c: char-Array
  string: char-Array pointer
  string2: Char-Array
  strings: Double pointer
  num: int
  nump: int pointer
  a: int
  b: int pointer

Belegung nach Ausführung des Programms
  JM:
    - string2 ist ein Pointer auf das erste Element des Arrays, der Inhalt von
      string2 ist deshalb eine Adresse.
    - strings zeigt zwar auf einen Speicherbereich, in dem mehrere Pointer
      hintereinander stehen, aber der Inhalt von strings ist nur die Adresse
      des ersten Pointers in diesem Speicherbereich.
      Damit ist *strings nur eine Adresse.
      *strings ist das gleiche wie strings[0].

  c = 'W'
  string2 = {'A','B', NULL, '\0'}
  string2[0] = A
  *strings = Liste von Adressen
  strings[2][2] = i
  string2[0] = 'A'
  num = 66

*strings[0] == *(string + 6) = True
b == *nump = True
b = nump = True
string == strings[1] = False

*/
